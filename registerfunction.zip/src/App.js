import React from 'react';
import RegisterFunction from './RegisterFunction';
 
function App() {
  return (
    <div>
      <RegisterFunction />
    </div>
    
  );
}
export default App;

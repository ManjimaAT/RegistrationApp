import React, { useState } from 'react';
import './register.css';

const RegistrationPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    age: '',
    companyName: ''
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  }

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Registration Data:', formData);
    setFormData({
      name: '',
      age: '',
      companyName: ''
    });
  }

  return (
    <div className="container">
      <h2>Registration Page</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Name:</label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            required
          />
          <span>{formData.name}</span>
        </div>
        <div>
          <label>Age:</label>
          <input
            type="number"
            name="age"
            value={formData.age}
            onChange={handleChange}
            required
          />
          <span>{formData.age}</span>
        </div>
        <div>
          <label>Company Name:</label>
          <input
            type="text"
            name="companyName"
            value={formData.companyName}
            onChange={handleChange}
            required
          />
          <span>{formData.companyName}</span>
        </div>
        <button className="btn" type="submit">Publish</button>
      </form>
    </div>
  );
}

export default RegistrationPage;

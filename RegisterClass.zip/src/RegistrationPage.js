import React, { Component } from 'react';
import './reg.css'
 
class RegistrationPage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: '',
      age: '',
      companyName: ''
    };
  }
 
  handleChange = (e) => {
    this.setState({
      [e.target.name]: e.target.value
    });
  }
 
  handleSubmit = (e) => {
    e.preventDefault();
    console.log('Registration Data:', this.state);
    this.setState({
      name: '',
      age: '',
      companyName: ''
    });
  }
 
  render() {
    return (
      <div class="container">
        <h2>Registration Page</h2>
        <form onSubmit={this.handleSubmit}>
          <div>
            <label>Name:</label>
            <input
              type="text"
              name="name"
              value={this.state.name}
              onChange={this.handleChange}
              required
               
            />
            {this.state.name}
          </div>
          <div>
            <label>Age:</label>
            <input
              type="number"
              name="age"
              value={this.state.age}
              onChange={this.handleChange}
              required
            />
            {this.state.age}
           
          </div>
          <div>
            <label>Company Name:</label>
            <input
              type="text"
              name="companyName"
              value={this.state.companyName}
              onChange={this.handleChange}
              required
            />
            {this.state.companyName}
          </div>
          <button class="btn" type="submit">Publish</button>
        </form>
      </div>
    );
  }
}
 
export default RegistrationPage;

